
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/generatePlan.ts
import Anthropic from "@anthropic-ai/sdk";

// netlify/functions/_shared/auth.ts
async function validateToken(token) {
  const expectedPassword = Netlify.env.get("VITE_APP_PASSWORD") || "dance2024";
  const secret = Netlify.env.get("SESSION_SECRET") || "dance-app-secret-2024";
  const encoder = new TextEncoder();
  const data = encoder.encode(expectedPassword + secret);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const expectedToken = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  return token === expectedToken;
}

// netlify/functions/generatePlan.ts
function normalizeCategory(cat) {
  switch (cat) {
    case "covered":
      return "worked-on";
    case "observation":
      return "needs-work";
    case "reminder":
      return "next-week";
    case "choreography":
      return "ideas";
    default:
      return cat;
  }
}
var generatePlan_default = async (request, _context) => {
  if (request.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  const authHeader = request.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "") || "";
  if (!token || !await validateToken(token)) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const apiKey = Netlify.env.get("ANTHROPIC_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "API key not configured" }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
    const body = await request.json();
    const { classInfo, notes, previousPlans, progressionHints, repetitionFlags, attendanceNote, expandedSummary } = body;
    if (!classInfo || !notes) {
      return new Response(JSON.stringify({ error: "Missing classInfo or notes" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const needsWork = notes.filter((n) => normalizeCategory(n.category) === "needs-work");
    const nextWeek = notes.filter((n) => normalizeCategory(n.category) === "next-week");
    const workedOn = notes.filter((n) => normalizeCategory(n.category) === "worked-on");
    const ideas = notes.filter((n) => normalizeCategory(n.category) === "ideas");
    const general = notes.filter((n) => !n.category);
    const isBalletClass = classInfo.name.toLowerCase().includes("ballet");
    const hasRecitalPiece = classInfo.recitalSong && classInfo.recitalSong.trim() !== "";
    const levelLabel = classInfo.level ? classInfo.level.charAt(0).toUpperCase() + classInfo.level.slice(1) : classInfo.name.toLowerCase().includes("advanced") ? "Advanced" : classInfo.name.toLowerCase().includes("intermediate") ? "Intermediate" : classInfo.name.toLowerCase().includes("beginner") ? "Beginner" : "";
    let context = `CLASS: ${classInfo.name} (${classInfo.day})`;
    if (levelLabel) context += `
LEVEL: ${levelLabel}`;
    if (hasRecitalPiece) {
      const pieceType = classInfo.isRecitalSong ? "Recital piece" : "Class combo";
      context += `
CURRENT PIECE: ${pieceType} \u2014 "${classInfo.recitalSong}"`;
    }
    if (classInfo.choreographyNotes) {
      context += `
CHOREO STATUS: ${classInfo.choreographyNotes}`;
    }
    if (attendanceNote) context += `
ATTENDANCE: ${attendanceNote}`;
    let notesBlock = "";
    if (nextWeek.length > 0) {
      notesBlock += `FLAGGED FOR NEXT WEEK:
${nextWeek.map((n) => `- ${n.text}`).join("\n")}

`;
    }
    if (needsWork.length > 0) {
      notesBlock += `NEEDS WORK:
${needsWork.map((n) => `- ${n.text}`).join("\n")}

`;
    }
    if (workedOn.length > 0) {
      notesBlock += `WORKED ON:
${workedOn.map((n) => `- ${n.text}`).join("\n")}

`;
    }
    if (general.length > 0) {
      notesBlock += `GENERAL:
${general.map((n) => `- ${n.text}`).join("\n")}

`;
    }
    if (ideas.length > 0) {
      notesBlock += `IDEAS:
${ideas.map((n) => `- ${n.text}`).join("\n")}

`;
    }
    let extraContext = "";
    if (expandedSummary && expandedSummary.trim()) {
      extraContext += `ORGANIZED CLASS SUMMARY (teacher-reviewed):
${expandedSummary.trim()}

`;
    }
    if (progressionHints && progressionHints.length > 0) {
      extraContext += `SUGGESTED PROGRESSIONS (from last week's work):
${progressionHints.map((h) => `- ${h}`).join("\n")}

`;
    }
    if (repetitionFlags && repetitionFlags.length > 0) {
      extraContext += `PATTERNS NOTICED:
${repetitionFlags.map((f) => `- ${f}`).join("\n")}

`;
    }
    if (previousPlans && previousPlans.length > 0) {
      extraContext += `PREVIOUS PLAN (for continuity):
${previousPlans[0].substring(0, 500)}

`;
    }
    const prompt = `You're a dance teacher writing your own quick prep notes for next week's class. You'll glance at these on your phone walking into the studio. Not a lesson plan \u2014 your personal cheat sheet.

${context}

THIS WEEK'S NOTES:
${notesBlock}${extraContext}WRITE YOUR PREP NOTES FOR NEXT WEEK. Follow these rules EXACTLY:

FORMAT:
- PLAIN TEXT ONLY. NEVER use: # ## ### ** * \` --- or any markdown syntax. If you output even one # character, the whole plan is ruined.
- Short bullet points with a dash (-)
- Group with simple ALL-CAPS labels on their own line ONLY when needed: PRIORITY, ${isBalletClass ? "BARRE" : "WARMUP"}, CENTER, ACROSS THE FLOOR, CHOREO${hasRecitalPiece ? `, PIECE ("${classInfo.recitalSong}")` : ""}
- Skip any section with nothing to say. Don't force structure.

EXAMPLE OF CORRECT FORMAT:
PRIORITY
- Run chass\xE9 combo again, they lost the timing
- Review port de bras from adagio

CENTER
- New tendu combination \u2014 add relev\xE9

EXAMPLE OF WRONG FORMAT (NEVER DO THIS):
## Priority
**Run chass\xE9 combo** again
- ### Center section

CONTENT PRIORITIES:
1. PRIORITY section FIRST \u2014 anything flagged for next week or needing more work. This is what you must not forget.
2. For each section of class you have notes on, write what to DO \u2014 not what you did. "Run chass\xE9 combo again" not "did chass\xE9 combo."
3. If a progression hint makes sense for this ${levelLabel || "class"} level, include it naturally (e.g., "progress jazz splits to traveling version"). Ignore any that feel too advanced or forced.
4. If a pattern was flagged (e.g., "3 weeks on X"), mention it as a nudge: "3 weeks on leaps \u2014 vary it or level up?"${hasRecitalPiece ? `
5. Always include a PIECE section for "${classInfo.recitalSong}" \u2014 what to work on, what section to clean, whether to run it full-out.` : ""}

TONE:
- You ARE the teacher. Write like you're scribbling on a Post-it.
- Specific. No generic advice. Every bullet should trace back to something from this week's notes.
- Terse. "Clean landing on switch leaps" not "Focus on improving the quality of landings when performing switch leaps."
- 8-12 bullets total. Ruthlessly cut anything that isn't actionable.
- No preamble, no sign-off, no encouragement, no "Great class!" fluff.`;
    const client = new Anthropic({ apiKey });
    const message = await client.messages.create({
      model: "claude-sonnet-4-5-20250929",
      max_tokens: 800,
      messages: [{ role: "user", content: prompt }]
    });
    let planContent = message.content[0].type === "text" ? message.content[0].text : "";
    planContent = planContent.replace(/^#{1,6}\s*/gm, "").replace(/\*\*([^*]+)\*\*/g, "$1").replace(/\*([^*]+)\*/g, "$1").replace(/`([^`]+)`/g, "$1").replace(/^---+$/gm, "").replace(/\n{3,}/g, "\n\n").trim();
    return new Response(JSON.stringify({
      success: true,
      plan: planContent,
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      classId: classInfo.id,
      className: classInfo.name
    }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("Error generating plan:", error);
    return new Response(JSON.stringify({
      error: "Failed to generate plan",
      details: error instanceof Error ? error.message : "Unknown error"
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
export {
  generatePlan_default as default
};
