
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.ts
async function validateToken(token) {
  const expectedPassword = Netlify.env.get("VITE_APP_PASSWORD") || "dance2024";
  const secret = Netlify.env.get("SESSION_SECRET") || "dance-app-secret-2024";
  const encoder = new TextEncoder();
  const data = encoder.encode(expectedPassword + secret);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const expectedToken = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  return token === expectedToken;
}

// netlify/functions/calendarProxy.ts
var BLOCKED_HOSTS = [
  "localhost",
  "127.",
  "0.0.0.0",
  "10.",
  "192.168.",
  "172.16.",
  "172.17.",
  "172.18.",
  "172.19.",
  "172.20.",
  "172.21.",
  "172.22.",
  "172.23.",
  "172.24.",
  "172.25.",
  "172.26.",
  "172.27.",
  "172.28.",
  "172.29.",
  "172.30.",
  "172.31.",
  "169.254.",
  "[::1]",
  "metadata.google",
  "metadata.aws"
];
var calendarProxy_default = async (request, _context) => {
  const authHeader = request.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "") || "";
  if (!token || !await validateToken(token)) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" }
    });
  }
  const url = new URL(request.url);
  const calendarUrl = url.searchParams.get("url");
  if (!calendarUrl) {
    return new Response(JSON.stringify({ error: "Missing url parameter" }), {
      status: 400,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const normalizedUrl = calendarUrl.replace(/^webcal:\/\//, "https://");
    let parsedUrl;
    try {
      parsedUrl = new URL(normalizedUrl);
    } catch {
      return new Response(JSON.stringify({ error: "Invalid URL" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    if (parsedUrl.protocol !== "https:") {
      return new Response(JSON.stringify({ error: "Only HTTPS URLs are allowed" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const hostname = parsedUrl.hostname.toLowerCase();
    if (BLOCKED_HOSTS.some((p) => hostname.startsWith(p) || hostname === p)) {
      return new Response(JSON.stringify({ error: "URL not allowed" }), {
        status: 403,
        headers: { "Content-Type": "application/json" }
      });
    }
    const response = await fetch(normalizedUrl, {
      headers: {
        "Accept": "text/calendar, text/plain, */*"
      }
    });
    if (!response.ok) {
      throw new Error(`Calendar fetch failed: HTTP ${response.status}`);
    }
    const icsText = await response.text();
    return new Response(icsText, {
      status: 200,
      headers: {
        "Content-Type": "text/calendar",
        "Cache-Control": "private, no-cache"
      }
    });
  } catch (error) {
    console.error("Calendar proxy error:", error);
    return new Response(JSON.stringify({ error: "Failed to fetch calendar" }), {
      status: 502,
      headers: { "Content-Type": "application/json" }
    });
  }
};
export {
  calendarProxy_default as default
};
